<?php
if(isset($_POST['save']))
{
    $tgl=explode("-",$tanngal);
    mysqli_query($con,"insert into pembukuan values('','$tgl[2]-$tgl[1]-$tgl[0]','$harga','$merktipe','$jenis_kerusakan')");
    echo "
    <script>
    location.assign('index.php?page=pembukuan&ps=true2');
    </script>
    ";
}
elseif(isset($_POST['update']))
{
    $tgl=explode("-",$tanngal);
    mysqli_query($con,"update pembukuan set tanngal='$tgl[2]-$tgl[1]-$tgl[0]',harga='$harga',merktipe='$merktipe',jenis_kerusakan='$jenis_kerusakan' where id='$id'");
    echo "
    <script>
    location.assign('index.php?page=pembukuan&ps=true1');
    </script>
    ";
}

/*pesan berhasil update*/
if(isset($_GET['ps'])=='true2')
    echo "<div class='alert alert-success' role='alert'>Data Berhasil Terupdate</div>";
elseif(isset($_GET['ps'])=='true1')
    echo "<div class='alert alert-success' role='alert'>Data Berhasil Terimpan</div>";

if(isset($_GET['id']))
{
    $data=mysqli_fetch_row(mysqli_query($con,"select * from pembukuan where id='".$_GET['id']."'"));
$tgl=explode("-",$data[1]);
}

?>
<div class="row">
    <div class="col-md-12">
        <div class="box box-info">
            <div class="box-header with-border">
               <div align="center"> <h3 class="box-title"><b>Form Input Pembukuan</b></h3> </div>
            </div>
            <form class="form-horizontal" method="post">
               <input type="hidden" name="id" value="<?php echo isset($data[0])?$data[0]:''; ?>">
                <div class="box-body">
                    <div class="form-group">
                        <label for="inputEmail3" class="col-sm-2 control-label">Tanggal</label>
                        <div class="col-sm-10">
                            <input type="text" id="tgl_agenda" required value="<?php echo isset($_GET['id'])?"$tgl[2]-$tgl[1]-$tgl[0]":""; ?>" name="tanngal" class="form-control" id="inputEmail3" placeholder="tanggal">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="dua1" class="col-sm-2 control-label">Id Barang</label>
                        <div class="col-sm-10">
                            <input type="text" required value="<?php echo isset($data[3])?$data[3]:''; ?>" name="id_barang" class="form-control" id="dua1" placeholder="Id Barang">
                        </div>
                    </div>					
                    <div class="form-group">
                        <label for="dua" class="col-sm-2 control-label">Ongkos Servis</label>
                        <div class="col-sm-10">
                            <input type="text" required value="<?php echo isset($data[2])?$data[2]:''; ?>" name="ongkos_servis" class="form-control" id="dua" placeholder="Ongkos Servis">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="dua1" class="col-sm-2 control-label">Pembelian</label>
                        <div class="col-sm-10">
                            <input type="text" required value="<?php echo isset($data[3])?$data[3]:''; ?>" name="pembelian" class="form-control" id="dua1" placeholder="Harga Beli">
                        </div>
                    </div>
					<div class="form-group">
                        <label for="tiga" class="col-sm-2 control-label">harga Jual</label>
                        <div class="col-sm-10">
                            <input type="text" required value="<?php echo isset($data[4])?$data[4]:''; ?>" name="harga_jual" class="form-control" id="tiga" placeholder="Harga Jual">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="tiga" class="col-sm-2 control-label">Merk & Tipe</label>
                        <div class="col-sm-10">
                            <input type="text" required value="<?php echo isset($data[4])?$data[4]:''; ?>" name="merk_tipe" class="form-control" id="tiga" placeholder="Merk & Tipe">
                        </div>
                    </div>

										                    <div class="form-group">
                        <label for="tiga" class="col-sm-2 control-label">Margin</label>
                        <div class="col-sm-10">
                            <input type="text" required value="<?php echo isset($data[4])?$data[4]:''; ?>" name="margin" class="form-control" id="tiga" placeholder="Margin">
                        </div>
										                    <div class="form-group">
                        <label for="tiga" class="col-sm-2 control-label">Margin Bulanan</label>
                        <div class="col-sm-10">
                            <input type="text" required value="<?php echo isset($data[4])?$data[4]:''; ?>" name="margin_bulanan" class="form-control" id="tiga" placeholder=" Bulanan">
                        </div>						
                    </div>
                </div>   
                <!-- /.box-body -->
                <div class="box-footer" align="center">
                    <input type="submit" class="btn btn-info pull-left" value="Save" name="<?php echo isset($_GET['id'])?'update':'save'; ?>">
                </div>
                <!-- /.box-footer -->
            </form>
        </div>
    </div>
    <!--/.col (right) -->
</div>   <!-- /.row -->
    