-- phpMyAdmin SQL Dump
-- version 4.1.12
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jan 04, 2016 at 10:15 AM
-- Server version: 5.6.16
-- PHP Version: 5.5.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `db_carousel`
--

-- --------------------------------------------------------

-- --------------------------------------------------------
--
-- Table structure for table `login`
--

CREATE TABLE IF NOT EXISTS `login` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `user` varchar(50) NOT NULL,
  `pass` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `user`, `pass`, `email`) VALUES
(1, 'aris', 'presley', 'aris.22002.priyanto@gmail.com');
-- --------------------------------------------------------

--
-- Table structure for table `pembelian`
--

CREATE TABLE IF NOT EXISTS `pembelian` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tanngal` date NOT NULL,
  `no_id` int(10) NOT NULL,
  `harga` int(10) NOT NULL,
  `merktipe` varchar(150) NOT NULL,
  `jenis_kerusakan` varchar(225) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=41 ;

--
-- Dumping data for table `pembelian`
--

INSERT INTO `pembelian` (`id`, `tanngal`,`no_id`, `harga`, `merktipe`, `jenis_kerusakan`) VALUES
(11, '2015-08-30', '000001', '130000', 'asus zf laser 2 550 ML', 'Layar set pecah matot'),
(12, '2015-08-31', '000002', '100000', 'Pusat Pelatihan Binus', 'Cisco Network Academy'),
(13, '2015-09-01', '000003', '100000', 'Wisma Menara Mulia', 'Pelatihan Sosialisasi Tunjangan Prestasi Kerja'),
(15, '2015-09-09', '000004', '100000', 'SMAN 1 Tahunan Jepara', 'Try out Gratis ');

-- --------------------------------------------------------


--
-- Table structure for table `pembukuan`
--

CREATE TABLE IF NOT EXISTS `pembukuan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tanngal` date NOT NULL,
  `harga_beli` int(10) NOT NULL,
  `ongkos_servis` int(10) NOT NULL,
  `harga_jual` int(10) NOT NULL,  
  `merktipe` varchar(70) NOT NULL,
  `margin` int(10) NOT NULL,


  
  PRIMARY KEY (`margin`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=41 ;

--
-- Dumping data for table `pembukuan`
--

INSERT INTO `pembelian` (`id`, `tanngal`, `no_id`, `harga_beli`, `ongkos_servis`, `harga_jual`, `merktipe`, `margin`) VALUES
(11, '2015-08-30', '1', '130000', '300000', '900000', 'asus zf 2 laser 550 ML','4000000'),
(12, '2015-08-31', '2', '100000', '300000', '900000', 'asus zf 2 laser 550 ML','4000000'),
(13, '2015-09-01', '3', '50000', '300000', '900000', 'asus zf 2 laser 550 ML','4000000'),
(15, '2015-09-09', '4', '75000', '300000', '900000', 'asus zf 2 laser 550 ML','4000000');

-- --------------------------------------------------------



/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
